define({ "api": [
  {
    "type": "get",
    "url": "/api/headline/description?id=",
    "title": "request description",
    "name": "GetHeadlineDescriptionByID",
    "group": "headline",
    "description": "<p>It is used to retrieve a specific headline's description</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "id",
            "description": "<p>headline's unique ID [0, 6]</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": "<p>a specific headline's description</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./main.go",
    "groupTitle": "headline"
  },
  {
    "type": "get",
    "url": "/api/headline/image?id=",
    "title": "request image's link",
    "name": "GetHeadlineImageByID",
    "group": "headline",
    "description": "<p>It is used to retrieve a specific headline's image as a link</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "id",
            "description": "<p>headline's unique ID [0, 6]</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": "<p>a specific headline's image as a link</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./main.go",
    "groupTitle": "headline"
  },
  {
    "type": "get",
    "url": "/api/headline/subtitle?id=",
    "title": "request subtitle",
    "name": "GetHeadlineSubtitleByID",
    "group": "headline",
    "description": "<p>It is used to retrieve a specific headline's subtitle</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "id",
            "description": "<p>headline's unique ID [0, 6]</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "subtitle",
            "description": "<p>a specific headline's subtitle</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./main.go",
    "groupTitle": "headline"
  },
  {
    "type": "get",
    "url": "/api/headline/title?id=",
    "title": "request title",
    "name": "GetHeadlineTitleByID",
    "group": "headline",
    "description": "<p>It is used to retrieve a specific headline's title</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "id",
            "description": "<p>headline's unique ID [0, 6]</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "title",
            "description": "<p>a specific headline's title</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./main.go",
    "groupTitle": "headline"
  },
  {
    "type": "get",
    "url": "/api/other/title",
    "title": "retrieve Persian title",
    "name": "GetOtherSportNewsPersianTitle",
    "group": "other",
    "description": "<p>It is used to retrieve the Persian form of other sport's title</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": "<p>the Persian form of other sport's title</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./main.go",
    "groupTitle": "other"
  },
  {
    "type": "get",
    "url": "/api/other/topic?id=",
    "title": "retrieve an entity",
    "name": "GetOtherSportTopicByID",
    "group": "other",
    "description": "<p>It is used to retrieve an entity of the other sport's data</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "id",
            "description": "<p>unique ID [0, 9]</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": "<p>an entity of the other sport's data</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./main.go",
    "groupTitle": "other"
  },
  {
    "type": "get",
    "url": "/api/recent/title",
    "title": "retrieve Persian title",
    "name": "GetRecentNewsPersianTitle",
    "group": "recent",
    "description": "<p>It is used to retrieve the Persian form of the most recent news title</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": "<p>the Persian form of the most recent news title</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./main.go",
    "groupTitle": "recent"
  },
  {
    "type": "get",
    "url": "/api/recent/topic?id=",
    "title": "retrieve an entity",
    "name": "GetRecentTopicByID",
    "group": "recent",
    "description": "<p>It is used to retrieve an entity of the the most recent news data</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "id",
            "description": "<p>unique ID [0, 9]</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": "<p>an entity of the most recent news data</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./main.go",
    "groupTitle": "recent"
  },
  {
    "type": "get",
    "url": "/api/trend/title",
    "title": "retrieve Persian title",
    "name": "GetTrendNewsPersianTitle",
    "group": "trend",
    "description": "<p>It is used to retrieve the Persian form of the trending news title</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": "<p>the Persian form of the trending news title</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./main.go",
    "groupTitle": "trend"
  },
  {
    "type": "get",
    "url": "/api/trend/topic?id=",
    "title": "retrieve an entity",
    "name": "GetTrendTopicByID",
    "group": "trend",
    "description": "<p>It is used to retrieve an entity of the trending news data</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "id",
            "description": "<p>unique ID [0, 9]</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": "<p>an entity of the trending news data</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./main.go",
    "groupTitle": "trend"
  },
  {
    "type": "get",
    "url": "/api/visit/title",
    "title": "retrieve Persian title",
    "name": "GetMostVisitedNewsPersianTitle",
    "group": "visit",
    "description": "<p>It is used to retrieve the Persian form of the most visited news title</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": "<p>the Persian form of the most visited news title</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./main.go",
    "groupTitle": "visit"
  },
  {
    "type": "get",
    "url": "/api/visit/topic?id=",
    "title": "retrieve an entity",
    "name": "GetMostVisitedTopicByID",
    "group": "visit",
    "description": "<p>It is used to retrieve an entity of the most visited news data</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "id",
            "description": "<p>unique ID [0, 9]</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": "<p>an entity of the most visited news data</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./main.go",
    "groupTitle": "visit"
  }
] });
