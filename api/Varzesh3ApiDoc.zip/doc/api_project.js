define({
  "name": "VARZESH3",
  "version": "1.0.0",
  "description": "VARZESH3 api doc",
  "title": "VARZESH3 api doc",
  "url": "varzesh3.herokuapp.com",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-06-02T21:32:57.967Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
